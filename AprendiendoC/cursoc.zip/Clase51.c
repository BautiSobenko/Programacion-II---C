Estructura de datos

Lineales

Cada elemento de la coleccion
precede y es precedido por otro
elemento, a excepcion de el
primero y el ultimo

(Lista)
(Pila) = Stack
(Cola) = Queue
*/

No lineales

Son precedidos por un unico
elemento pero pueden preceder
a 2 o mas,excepto el 1ro

Arboles, grafos, etc


